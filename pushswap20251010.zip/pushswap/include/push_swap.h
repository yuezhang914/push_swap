/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yzhang2 <yzhang2@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/22 17:01:11 by yzhang2           #+#    #+#             */
/*   Updated: 2025/10/10 05:51:24 by yzhang2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include "libft/libft.h"
# include <limits.h>
# include <stdbool.h>

typedef struct s_node
{
	int				value;
	int				index;
	int				cost;
	bool			up_down;
	bool			cheapest;
	struct s_node	*prev;
	struct s_node	*next;
	struct s_node	*target;
}					t_node;

int					not_num(char *str);
int					if_dup(t_node *s, int i);

void				free_stack(t_node **s);
void				handle_error(t_node **s);

int					safe_parse_int(const char *s, int *out);
int     init_stack_a(t_node **a, char **values); 
void    append_node(t_node **stack, int value);


void				free_split(char **arr);

#endif