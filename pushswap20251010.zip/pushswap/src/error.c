/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yzhang2 <yzhang2@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/10 04:15:51 by yzhang2           #+#    #+#             */
/*   Updated: 2025/10/10 05:19:01 by yzhang2          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	free_stack(t_node **s)
{
	t_node	*tmp;
	t_node	*current;

	if (!s)
		return ;
	current = *s;
	while (current)
	{
		tmp = current->next;
		current->value = 0;
		free(current);
		current = tmp;
	}
	*s = NULL;
}

void	handle_error(t_node **s)
{
	free_stack(s);
	ft_printf("Error\n");
	exit(1);
}
